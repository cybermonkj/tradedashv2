<?php
    
?><?php /**PATH /home/hosthikr/test.hostmeng.com.ng/core/resources/views/user/inc/fetch.blade.php ENDPATH**/ ?>