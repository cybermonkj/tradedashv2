<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class fund_transfer extends Model
{
    protected $table="fund_transfer";
}
